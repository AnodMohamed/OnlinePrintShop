

<main>
    <div class="content-area">
        <section class="page-section breadcrumbs">
            <div class="container">
                <div class="page-header">
                    <h1> Add  Category</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="<?php echo e(route('admin.categories')); ?>">Manage Categories</a></li>
                    <li class="active">Add Category</li>
                </ul>
            </div>
        </section>
        <section class="page-section ">
            <div class="container"  style="width:1000px">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                 <?php endif; ?>
                <form name="contact-form"   wire:submit.prevent="storeCategory" class="contact-form" id="contact-form">

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label class="sr-only" for="name">Category Name</label>
                            <input type="text" wire:model="name"  wire:keyup=" generaleslug" name="name" id="name" placeholder="Category Name" value="" size="30" data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Name is required">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label class="sr-only" for="slug">Category Slug</label>
                            <input type="text" wire:model="slug" name="slug" id="slug" placeholder="Category Slug" value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="slug is required">
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="required" style="text-align: center;">
                        <button  type="submit" class="btn  btn-theme btn-theme-dark " > Add Category</button>
                    </div>

                </form>

            </div>
        </section>
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\OnlinePrintShop\resources\views/livewire/admin/add-category-component.blade.php ENDPATH**/ ?>