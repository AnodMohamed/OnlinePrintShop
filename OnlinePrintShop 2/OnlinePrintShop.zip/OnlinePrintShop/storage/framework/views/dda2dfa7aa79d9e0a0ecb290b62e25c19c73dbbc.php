

<main>
    <div class="content-area">
        <section class="page-section breadcrumbs">
            <div class="container">
                <div class="page-header">
                    <h1> Add Product</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="<?php echo e(route('admin.products')); ?>">Manage Products </a></li>  
                    <li class="active">Add Product</li>
                </ul>
            </div>
        </section>
        <section class="page-section ">
            <div class="container"  style="width:1000px">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                 <?php endif; ?>
                <form name="contact-form"   wire:submit.prevent="storeProduct" class="contact-form" id="contact-form" enctype="multipart/form-data">

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label for="name">Product Name</label>
                            <input type="text" wire:model="name" wire:keyup=" generateSlug" name="name" id="name" placeholder="Product Name" value="" size="30" data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Product is required">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="slug">Product Slug</label>
                            <input type="text" wire:model="slug" name="slug" id="slug" placeholder="Product Slug" value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="slug is required">
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="outer required" wire:ignore>
                        <div class="form-group af-inner">
                            <label  for="slug">Short Description</label>
                            <textarea type="text" wire:model="short_description" name="short_description" id="short_description" placeholder="Short Description" value=""  title="" class="form-control placeholder" ></textarea>
                            <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="outer required" wire:ignore>
                        <div class="form-group af-inner">
                            <label  for="description"> Description</label>
                            <textarea type="text" wire:model="description" name="description" id="description" placeholder="description" value=""   title="" class="form-control placeholder" ></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
     
                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="regular_price"> Regular Price</label>
                            <input type="text" wire:model="regular_price" name="regular_price" id="regular_price" placeholder="regular Price" value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="regular price is required">
                            <?php $__errorArgs = ['regular_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="sale_price"> Sale Price</label>
                            <input type="text" wire:model="sale_price" name="sale_price" id="sale_price" placeholder="Sale Price" value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Sale Price is required">
                            <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="SKU"> SKU</label>
                            <input type="text" wire:model="SKU" name="SKU" id="SKU" placeholder="SKU " value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="SKU is required">
                            <?php $__errorArgs = ['SKU'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
  
                    
                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="stock_status"> Stock</label>
                            <select wire:model="stock_status" name="stock_status" id="stock_status" placeholder="Stock status " value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Stock status is required">
                                <option value="">Select</option>
                                <option value="instock">InStock </option>
                                <option value="outofstock">Out of Stock </option>
                            </select>
                            <?php $__errorArgs = ['stock_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>   

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="featured"> Featured</label>
                            <select wire:model="featured" name="featured" id="featured" placeholder="Featured " value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Featured is required">
                                <option value="">Select</option>
                                <option value="0">No </option>
                                <option value="1">Yes </option>
                            </select>
                            <?php $__errorArgs = ['featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div> 

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="quantity"> Quantity</label>
                            <input type="text" wire:model="quantity" name="quantity" id="quantity" placeholder="Quantity " value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Quantity is required">

                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div> 

                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="image"> Product Image</label>
                            <input type="file" wire:model="image" name="image" id="image" placeholder="Product Image " value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="Product Image is required">

                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if($image): ?>
                                <img src="<?php echo e($image->temporaryUrl()); ?>" width="120" hieght="120" />
                            <?php endif; ?>      
                        </div>
                    </div> 

                    
                <div class="mb-6 col-8">
                    <label class=" control-label">Product Gallery </label>
                    <p class="text-secondary">Select all images one time </p>
                    <input type="file" placeholder="Product images" class="form-control input-md input-file" wire:model="images" multiple/>
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($images): ?>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e($img->temporaryUrl()); ?>" width="120" hieght="120" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div> 
                
                    <div class="outer required">
                        <div class="form-group af-inner">
                            <label  for="SKU"> Category</label>
                            <select wire:model="category_id" name="category_id" id="category_id"  value=""  data-toggle="tooltip" title="" class="form-control placeholder" data-original-title="category is required">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>   
              

                    <div class="required" style="text-align: center;">
                        <button  type="submit" class="btn  btn-theme btn-theme-dark " > Add Product</button>
                    </div>

                </form>

            </div>
        </section>
    </div>
</main>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function(){
            tinymce.init({
                selector: '#short_description',
                setup: function (editor) {
                    editor.on('Change', function(e){
                        tinyMCE.triggerSave();
                        var sd_data = $('#short_description').val();
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('short_description', sd_data);
                    })
                }
            });
            tinymce.init({
                selector: '#description',
                setup: function (editor) {
                    editor.on('Change', function(e){
                        tinyMCE.triggerSave();
                        var sd_data = $('#description').val();
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('description', sd_data);
                    })
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\OnlinePrintShop\resources\views/livewire/admin/add-product-component.blade.php ENDPATH**/ ?>