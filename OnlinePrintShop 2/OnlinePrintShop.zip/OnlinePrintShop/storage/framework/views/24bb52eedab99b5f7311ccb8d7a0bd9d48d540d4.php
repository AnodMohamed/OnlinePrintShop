<main>
    <div class="content-area">
        <section class="page-section breadcrumbs">
            <div class="container">
                <div class="page-header">
                    <h1>My orders</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">My orders</li>
                </ul>
            </div>
        </section>
        <section class="page-section">
            <div class="container">
                <?php if(!$Orders->isEmpty()): ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name </th>
                            <th scope="col">subtotal</th>
                            <th scope="col">discount</th>
                            <th scope="col">tax </th>
                            <th scope="col">total  </th>
                            <th scope="col">firstname</th>

                            <th scope="col">lastname</th>
                            <th scope="col">Email</th>
                            <th scope="col">mobile</th>
                            <th scope="col">email </th>
                            <th scope="col">line1  </th>
                            <th scope="col">line2</th>

                            <th scope="col">province</th>
                            <th scope="col">zipcode</th>
                            <th scope="col">shippmode</th>
                            <th scope="col">paymentmode </th>
                            <th scope="col">status </th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $Orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($Order->id); ?></th>
                            <td><?php echo e($Order->subtotal); ?></td>
                            <td><?php echo e($Order->discount); ?></td>
                            <td><?php echo e($Order->tax); ?></td>
                            <td><?php echo e($Order->total); ?></td>

                            <th><?php echo e($Order->firstname); ?></th>
                            <td><?php echo e($Order->lastname); ?></td>
                            <td><?php echo e($Order->mobile); ?></td>
                            <td><?php echo e($Order->email); ?></td>
                            <td><?php echo e($Order->line1); ?></td>

                            <th><?php echo e($Order->line2); ?></th>
                            <td><?php echo e($Order->province); ?></td>
                            <td><?php echo e($Order->shippmode); ?></td>
                            <td><?php echo e($Order->paymentmode); ?></td>
                            <td><?php echo e($Order->status); ?></td>

                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center">There is no user to display</p>
                <?php endif; ?>
                
            </div>
        </section>
        
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\OnlinePrintShop 2\OnlinePrintShop\resources\views/livewire/admin/manage-orders-component.blade.php ENDPATH**/ ?>