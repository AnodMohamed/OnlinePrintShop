<div >
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
            <section class="page-section breadcrumbs ">
                <div class="container">
                    <div class="page-header">
                        <h2 class="section-title"><span>View Product</span></h2>
                        <ul class="breadcrumb">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="active"><a href="<?php echo e(route('admin.products')); ?>">Mang My Ads</a> </li>
                            <li class="active">View Product</li>
                        </ul>
                    </div>
                </div>
            </section>
            <div class="row product-single">
                
                              

              
            <div class="col-md-6">

                <div class="owl-carousel img-carousel">
                 
                    <?php $__currentLoopData = $imagex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($img)): ?>
                            <div class="item">
                                <a class="btn btn-theme btn-theme-transparent btn-zoom" href="<?php echo e(asset('storage/gallery')); ?>/<?php echo e($img); ?>" data-gal="prettyPhoto" ><i class="fa fa-plus"></i></a>
                                <a href="<?php echo e(asset('storage/gallery')); ?>/<?php echo e($img); ?>" data-gal="prettyPhoto"><img class="img-responsive" src="<?php echo e(asset('storage/gallery')); ?>/<?php echo e($img); ?>" alt="" /></a>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </div>
                <div class="row product-thumbnails">
                    <?php $__currentLoopData = $imagex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($img)): ?>
                            <div class="col-xs-2 col-sm-2 col-md-3"><a href="#" onclick="jQuery('.img-carousel').trigger('to.owl.carousel', [0,300]);"><img src="<?php echo e(asset('storage/gallery')); ?>/<?php echo e($img); ?>" alt=""/></a></div>
                         <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
                        <div class="col-md-6">
                            <h2 class="product-title">Name :<?php echo e($name); ?></h2>
                            <div class="product-rating clearfix">
                            
                                <span class="reviews">Short description:</span> |<span class="add-review" ><?php echo e($short_description); ?></span>
                            </div>
                            <hr class="page-divider small"/>

                            <div class="product-price">Price: <?php echo e($regular_price); ?></div>
                            <div class="product-price">Sale: <?php echo e($sale_price); ?></div>

                            <hr class="page-divider"/>

                            <div class="product-text">
                                <p> Description :</p>
                                <p> <?php echo e($description); ?></p>
                                
                            </div>
                            <hr class="page-divider"/>
                            <hr class="page-divider small"/>

                            <hr class="page-divider small"/>

                            <table>
                                <tr>
                                    <td class="title">Featured:</td>
                                    <td>
                                        <?php if($featured == "1"): ?>
                                            Yes 
                                        <?php else: ?>
                                            No   
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="title">Quantity :</td>
                                    <td><?php echo e($quantity); ?></td>
                                </tr>
                                <tr>
                                    <td class="title">Category :</td>
                                    <td><?php echo e($product->category->name); ?></td>
                                </tr>
                            
                            </table>
                            
                            <hr class="page-divider small"/>
                            
                        

                        </div>
            </div>

        </div>
    </section>
    <!-- /PAGE -->



    <!-- PAGE -->
    
   
    </div>
    </div>
  </div>
</div>
<!-- /CONTENT AREA --><?php /**PATH C:\xampp\htdocs\OnlinePrintShop\resources\views/livewire/admin/admin-view-product-component.blade.php ENDPATH**/ ?>