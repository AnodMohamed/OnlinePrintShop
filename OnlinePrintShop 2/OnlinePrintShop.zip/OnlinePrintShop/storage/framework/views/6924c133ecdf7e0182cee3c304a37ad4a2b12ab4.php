<main>
    <div class="content-area">
        <section class="page-section breadcrumbs">
            <div class="container">
                <div class="page-header">
                    <h1>Manage Categories</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">Manage Categories</li>
                </ul>
            </div>
        </section>
        
        <section class="page-section ">
            <?php if(!$categories->isEmpty()): ?>

                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="col-md-4">
                    <input type="text" class="form-control" placeholder="Search...." wire:model="searchTerm">
                </div>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Slug</th>
                            <th scope="col">Created at</th>
                            <th scope="col">Updated at </th>
                            <th scope="col">Control</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($category->id); ?></th>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->slug); ?></td>
                            <td><?php echo e($category->created_at); ?></td>
                            <td><?php echo e($category->updated_at); ?></td>

                            <td> 
                                <a herf="" onclick="confirm('Are you sure, You want to delete <?php echo e($category->name); ?> category') || event.stopImmediatePropagation()"  wire:click.prevent="deleteCategory(<?php echo e($category->id); ?>)" style="margin-left:10px "  class="btn btn-danger "> 
                                Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                
            <?php else: ?>
                <div class="col-md-12">
                    <p class="text-center">There is no category to display</p>
                </div>
            <?php endif; ?>
                <div class="required" style="text-align: center;">
                    <a href="<?php echo e(route('admin.AddCategory')); ?>"   class="btn  btn-theme btn-theme-dark " > Add Category</a>
                </div>
            

        </section>
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\OnlinePrintShop\resources\views/livewire/admin/manage-category-component.blade.php ENDPATH**/ ?>