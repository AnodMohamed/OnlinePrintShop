<main>
    <div class="content-area">
        <section class="page-section breadcrumbs">
            <div class="container">
                <div class="page-header">
                    <h1>Manage Products</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">Manage Products</li>
                </ul>
            </div>
        </section>
        
        <section class="page-section ">
            <?php if(!$products->isEmpty()): ?>

                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="col-md-4">
                    <input type="text" class="form-control" placeholder="Search...." wire:model="searchTerm">
                </div>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Stock status</th>
                            <th scope="col">Regular price</th>
                            <th scope="col">Sale price</th>
                            <th scope="col">Created at</th>
                            <th scope="col">Control</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td ><?php echo e($product->id); ?></td>
                                <td ><img src="<?php echo e(asset('storage/products')); ?>/<?php echo e($product->image); ?>" width="60" /> </td>
                                <td ><?php echo e($product->name); ?></td>
                                <td ><?php echo e($product->stock_status); ?></td>
                                <td ><?php echo e($product->regular_price); ?></td>
                                <td ><?php echo e($product->sale_price); ?></td>
                                <td ><?php echo e($product->created_at); ?></td>
                                <td >
                                    <a herf="" onclick="confirm('Are you sure, You want to delete <?php echo e($product->name); ?> product') || event.stopImmediatePropagation()"  wire:click.prevent="deleteProduct(<?php echo e($product->id); ?>)" style="margin-left:10px "  class="btn btn-danger "> 
                                        Delete
                                    </a>
                                    <a href="<?php echo e(route('admin.viewProduct',['product_slug'=>$product->slug ])); ?>" class="btn btn-info " style="margin-left:10px ">
                                        View
                                     </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                       
                        
                        </tbody>
                    </table>
                
            <?php else: ?>
                <div class="col-md-12">
                    <p class="text-center">There is no product to display</p>
                </div>
            <?php endif; ?>
                <div class="required" style="text-align: center;">
                    <a href="<?php echo e(route('admin.addProduct')); ?>"   class="btn  btn-theme btn-theme-dark " > Add Product</a>
                </div>
            

        </section>
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\OnlinePrintShop\resources\views/livewire/admin/manage-product-component.blade.php ENDPATH**/ ?>